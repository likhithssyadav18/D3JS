function doNut(cnt,vow,cons,punc)
{
				
	let svg_pie_1=document.querySelector('#pie_div')
	const margin=parseInt(getComputedStyle(svg_pie_1).padding,10);
	
	let svg_pie=document.querySelector('svg');
	const width=parseInt(getComputedStyle(svg_pie).width,10);
	const height=parseInt(getComputedStyle(svg_pie).height,10);
	
	
	let donutwidth=75;
	//const width = +svg.style('width').replace('px','');
	//const height = +svg.style('height').replace('px','');
	let radius = Math.min(width,height)/2;					
	
	
	let svg1=d3.select('#pie_svg').append('g')
				.attr("id","pie_g")
				.attr('transform', 'translate(' + width/2 + ',' + height/2 + ')');
	
	let arc = d3.arc().innerRadius(radius-donutwidth-margin).outerRadius(radius-margin);
	
	//let cnt=submitText()["cnt"];
	//console.log(cnt,'Ji');
	let cnt_key=[];
	let cnt_val=[];
	//console.log(Object.entries(cnt),'123');
	for(const [a,b] of Object.entries(cnt)) 
	{
			cnt_key.push(b["key"]);
			cnt_val.push(b["value"]);
	}
	
	//console.log(cnt_key);
	//console.log(cnt_val);
		
	let pie = d3.pie().value(d=>d.value).sort(null).padAngle(.001);
	let data=pie(cnt);
	
	//console.log(data);
	
	let color=d3.scaleOrdinal(d3.schemeAccent).domain(cnt_key).range(["#A52A2A", "#72A0C1", "#568203", "#FFC72C"]);
	
	let path=d3.select("#pie_svg").select('#pie_g')
				.selectAll('path')
				.data(data)
				.enter()
				.append('path')
				.attr('d',arc)
				.attr('fill',(d,i)=>color(d.data.key))
				.style('stroke','black')
				.style('stroke-width',1)
				.on("mouseover", function(d,i){
							//console.log('50',i.data);
							d3.select(this).style("stroke","black").style("stroke-width",4).transition();
							
							svg1.append('text')
									.attr('text-anchor','middle')
									.attr('x',5)
									.attr('y',-10)
									.text(i.data.key+" : "+i.data.value);
									})
				
				.on("click", function(d,i){
									//console.log('50',i);
									svg.selectAll("*").remove();
									if(i.data.key=="vowels"){barChart(vow,"vow",'Vowels','.vow');}
									else if(i.data.key=="consonants"){barChart(cons,"cons",'Consonants','.cons');}
									else if(i.data.key=="punctuations"){barChart(punc,"punc",'Punctuations','.punc');}
									else{barChart(dig,"dig",'Digits','.dig');}
									})
				/*.on("dblclick", function(d,i){
									//console.log('50',i);
									if(i.data.key=="vowels"){svg.selectAll("*").remove();}
									else if(i.data.key=="consonants"){svg.selectAll("*").remove();}
									else if(i.data.key=="punctuations"){svg.selectAll("*").remove();}
									else{svg.selectAll("*").remove();}
									})*/
				.on("mouseout", function(d){
									path.attr('opacity', '1').style('stroke-width',1);
									svg1.selectAll("text").remove();
									});
		}