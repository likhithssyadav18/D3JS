const margin = { top: 60, right: 150, bottom: 120, left: 120 };
let svg;
let onLoad = () => {
	svg = d3.select('#svg1').append('g')
		.attr("id","chart_g")
		.attr('transform', `translate(${margin.left}, ${margin.top})`);	
}
let formatYear = d3.timeFormat("%Y");
let CR_data, GD_data,GD_filter,CR_filter;

//multicheckbox select option
var expanded = false;
function showCheckboxes() {
	var checkboxes = document.getElementById("checkboxes");
	if (!expanded) {
		checkboxes.style.display = "block";
		expanded = true;
	} else {
		checkboxes.style.display = "none";
		expanded = false;
	}
}

function checked(value) {
	var checkBox = document.getElementById("myCheck");
	var text = document.getElementById("text");
	if (checkBox.checked == true) {
		text.style.display = "block";
	} else {
		text.style.display = "none";
	}
}

function selectAll() {
	let cboxes = document.getElementsByName("cbox");
	for (let i = 0; i < cboxes.length; i++) {
		if (cboxes[i].checked == true) {
			continue;
		}
		else {
			cboxes[i].checked = true;
		}
	}
	getRegion(CR_data,GD_data);
}

function deselectAll() {
	let cboxes = document.getElementsByName("cbox");
	for (let i = 0; i < cboxes.length; i++) {
		if (cboxes[i].checked == false) {
			continue;
		}
		else {
			cboxes[i].checked = false;
		}
	}
	getRegion(CR_data,GD_data);
}



document.addEventListener('DOMContentLoaded', function () {
   // Hint: create or set your svg element inside this function
    	
   // This will load your two CSV files and store them into two arrays.
   let svg_append = d3.select('#svg1').append('g')
					.attr('transform', `translate(${margin.left}, ${margin.top})`);
    Promise.all([d3.csv('global_development.csv',function(c) {
											return {
													Country: c['Country'],
													Year: new Date(+c.Year, 0, 1),
													Hlth_brt_rt: +c['Data.Health.Birth Rate'],
													Htlh_dt_rt: +c['Data.Health.Death Rate'],
													Hlth_frt_rt: +c['Data.Health.Fertility Rate'],
													Hlth_tot_pg: +c['Data.Health.Population Growth'],
													Inf_Tel_Lns_per: +c['Data.Infrastructure.Telephone Lines per 100 People'],
													Inf_Mob_Cell_Subs_per: +c['Data.Infrastructure.Mobile Cellular Subscriptions per 100 People'],
													RD_aglnd_per: +c['Data.Rural Development.Agricultural Land Percent'],
													RD_rur_pg: +c['Data.Rural Development.Rural Population Growth'],
													UD_urb_pop_per:+c['Data.Urban Development.Urban Population Percent'],
													UD_urb_pop_pg:+c['Data.Urban Development.Urban Population Percent Growth'],
													Color: c.Color,
													FlagSVG: c['FlagSVG']
												};
											}),
				d3.csv('countries_regions.csv',function(d) {
											return {
													Name: d.name,
													World_Bank_Region: d['World bank region'],
													Color: d.Color
												};
											})
				])		
        .then(function (values) {
            console.log('loaded global_development.csv and countries_regions.csv');
            GD_data = values[0];
            CR_data = values[1];
			//console.log(CR_data,GD_data);
			getRegion(CR_data,GD_data);
		});		
});

function getRegion(CR_data_local, GD_data_local) {
	//d3.select("svg").remove();
	let start=new Date(d3.select("#start").property('value'),0,1);
	//console.log('123',start)
	let end=new Date(d3.select("#end").property('value'),0,1);
	//console.log('123',end)
	//console.log(start,end)
	document.getElementById("demo").innerHTML = start.getFullYear() +" to "+ end.getFullYear();

	if (CR_data_local !== undefined && GD_data_local !== undefined) {
		CR_data = CR_data_local; GD_data = GD_data_local;
	}
	//console.log(CR_data)
	let cboxes = document.getElementsByName("cbox");
	let reg=[],countries=[];
	for (let i = 0; i < cboxes.length; i++) {
		if (cboxes[i].checked == true) {
			reg.push(document.getElementById(cboxes[i].id).value);
		}
		else {
			continue;
		}
	}
	//let GD_filter, CR_filter;
	//console.log(reg);
	

	if (reg.includes("South Asia")) {
		CR_filter = CR_data.filter(obj => {
			if (obj.World_Bank_Region === "South Asia") {
				countries.push(obj.Name);
				return true;
			}
		});

		//drawLineChart(GD_filter,ind_select,".sasia");
	}

	if (reg.includes("Europe & Central Asia")) {
		CR_filter = CR_data.filter(obj => {
			if (obj.World_Bank_Region === "Europe & Central Asia") {
				countries.push(obj.Name);
				return true;
			}
		});
		//drawLineChart(GD_filter,ind_select,".ecasia");
	}

	if (reg.includes("Middle East & North Africa")) {
		CR_filter = CR_data.filter(obj => {
			if (obj.World_Bank_Region === "Middle East & North Africa") {
				countries.push(obj.Name);
				return true;
			}
		});
		//drawLineChart(GD_filter,ind_select,".mena");
	}

	if (reg.includes("Sub-Saharan Africa")) {
		CR_filter = CR_data.filter(obj => {
			if (obj.World_Bank_Region === "Sub-Saharan Africa") {
				countries.push(obj.Name);
				return true;
			}
		});

		//drawLineChart(GD_filter,ind_select,".ssa");
	}

	if (reg.includes("Latin America & Caribbean")) {
		CR_filter = CR_data.filter(obj => {
			if (obj.World_Bank_Region === "Latin America & Caribbean") {
				countries.push(obj.Name);
				return true;
			}
		});
		//drawLineChart(GD_filter,ind_select,".lac");
	}

	if (reg.includes("East Asia & Pacific")) {
		CR_filter = CR_data.filter(obj => {
			if (obj.World_Bank_Region === "East Asia & Pacific") {
				countries.push(obj.Name);
				return true;
			}
		});

		//drawLineChart(GD_filter,ind_select,".eap");
	}

	if (reg.includes("North America")) {
		CR_filter = CR_data.filter(obj => {
			if (obj.World_Bank_Region === "North America") {
				countries.push(obj.Name);
				return true;
			}
		});
		//drawLineChart(GD_filter,ind_select,".na");
	}

	GD_filter = GD_data.filter(obj => {
		for (let k = 0; k < countries.length; k++) {
			if (obj.Country === countries[k] && (obj.Year>=start && obj.Year<=end) && (obj.Color!=="" && obj.FlagSVG!=="")) {
					return true;
			}
		}
	});
	//console.log(countries);
	//console.log(GD_filter)
	let ind_select = d3.select('#global_indicator').property('value');
	drawLineChart(GD_filter,ind_select,start,end);
}

function drawLineChart(GD_filter,ind_select,start,end)
{
	svg.selectAll("path").remove();
	svg.selectAll("#yScale").remove();
	svg.selectAll("#xScale").remove();
	svg.selectAll("#lab").remove();
	svg.selectAll("#cir").remove();

	
	//console.log('213',ind_select)
	//let GD_filter=getRegion(CR_data,GD_data);
	//console.log('23',GD_filter)
	if (ind_select == "NA") { }
	else
	{
		let svg_line = document.querySelector('#svg1');

		const width = parseInt(getComputedStyle(svg_line).width, 10);
		const height = parseInt(getComputedStyle(svg_line).height, 10);
		const innWidth = width - margin.left - margin.right;
		const innHeight = height - margin.top - margin.bottom;

		let data2 = d3.group(GD_filter, d=>d.Country);
		//console.log('21', data2);
		//console.log(start,end)
		// X-Axis
		let x_scl = d3.scaleTime().range([1,innWidth]).nice();
		x_scl.domain([start,end]);
		//console.log([start,end]);
		let x_axis = d3.axisBottom(x_scl).tickFormat(d3.timeFormat("%Y"));
		svg.append('g')
			.attr('id','xScale')
			.call(x_axis)
			.attr('transform', `translate(0,${innHeight})`)
			.selectAll('text')
			.style('text-anchor', 'end')
			.attr('dx', '-10px')
			.attr('dy', '-5px')
			.attr('transform', 'rotate(-90)');

		svg.append('text')
			.attr('text-anchor', 'middle')
			.attr('x', innWidth / 2)
			.attr('y', innHeight + 70)
			.text('Year');
		
		//Y-Axis
		let y_scl = d3.scaleLinear().range([innHeight, 0]).nice();
		let y_axis = d3.axisLeft(y_scl);
		svg.append('g')
			.attr('id','yScale')
			.call(y_axis);

		svg.append('text')
			.attr('transform', 'rotate(-90)')
			.attr('y', -70)
			.attr('x', -innHeight / 2)
			.attr('text-anchor', 'middle')
			.text('Selected Global Development Attribute Scale');

		let tip = d3.select("body")
			.append("div")
			.style("position", "absolute")
			.style("width","auto")
			.style("height","auto")
			.style("text-align","center")
			.style("z-index", "10")
			.style("visibility", "hidden")
			.style("padding", "15px")
			.style("background", "black")
			.style("border", "2px")
			.style("margin", "5px")
			.style("border-radius", "8px")
			.style("color", "white")
			.style("font-family","sans-serif")
			.style("font-size","15px")
			.style("line-height","20px")
			.style("pointer-events","none");

		function update(filter,data,ind_option)
		{
			y_scl.domain(d3.extent(filter, a => a[ind_option]));
			svg.selectAll("#yScale")
					.transition()
                    .duration(1500)
					.delay(600)
                    .call(y_axis);

			x_scl.domain([start,end]);

			svg.selectAll("#xScale")
					.transition()
    				.duration(1500)
					.delay(600)
    				.call(x_axis);

			let t = svg.transition().duration(3000).delay(800);	

			function lineLegends() 
			{
					svg.selectAll("myPoints")
						.data(data2)
						.enter()
						.append('g')
						  .append("circle")
						.datum(function(d) { return {Country:d[1][d[1].length-1]["Country"], Year: d[1][d[1].length-1]["Year"], Color:d[1][d[1].length-1]["Color"], Value: d[1][d[1].length-1][ind_option]}; })
						.attr("id","cir")
						  .attr("cx", function(d) {  return x_scl(d.Year)} )
						  .attr("cy", function(d) {  return y_scl(d.Value)} )
						  .attr("r", 6)
						  .attr("stroke", "white")
						  .style("fill", function(d){ return d.Color; })
						  .attr("opacity", 0)
						  .on("mouseover", function(d,i) {
							//console.log(d,i)
							d3.select(this).style("stroke-width",2).select("#line").style("stroke-width",5).select("#lab").style("stroke-width",1.5);
							tip.html(`Value: ${i.Value}`)
									.style("visibility", "visible")
									.style("left",(event.pageX)+"px")
									.style("top", (event.pageY)+"px");	
							  })
							  .on("mouseout", function(d,i) {
								d3.select(this).style("stroke-width",1).select("#line").style("stroke-width",1.5).select("#lab").style("stroke-width",0.7);
								tip.style("visibility", "hidden");	
							})
							.on("mousemove",function(d,i) {
								tip.style("top", (event.pageY)+"px").style("left",(event.pageX)+"px");
							})
  						  .transition()
						  .duration(500)
						  .delay(600)
					      .attr("opacity", 1);
					  
				
					svg.selectAll("myLabels")
						.data(data2)
						.enter()
						.append('g')
						.append("text")
						.datum(function(d) { return {Country:d[1][d[1].length-1]["Country"], Year: d[1][d[1].length-1]["Year"], Color:d[1][d[1].length-1]["Color"], Value: d[1][d[1].length-1][ind_option]}; })
						.attr("transform", function(d) { //console.log('999',d);  
								  return "translate(" + x_scl(d.Year) + "," + y_scl(d.Value) + ")"; })
						.attr("id","lab")
						.attr('x',5)
						.style("font-size", '15')
						.text(function(d) { return d.Country; })
						.style("fill", function(d){ return d.Color; })
						.attr("opacity", 0)
						.on("mouseover", function(d,i) {
							d3.select(this).style("stroke-width",1.5).select("#line").style("stroke-width",5).select("#cir").style("stroke-width",2);
							tip.html(`Value: ${i.Value}`)
									.style("visibility", "visible")
									.style("left",(event.pageX)+"px")
									.style("top", (event.pageY)+"px");		  
						})
						.on("mouseout", function(d,i) {
								d3.select(this).style("stroke-width", 0.7).select("#line").style("stroke-width",1.5).select("#cir").style("stroke-width",1);
								tip.style("visibility", "hidden");
							})
						.on("mousemove",function(d,i) {
								tip.style("top", (event.pageY)+"px").style("left",(event.pageX)+"px");
							})
  						.transition()
						.duration(500)
						.delay(600)
					    .attr("opacity", 1);
						//.transition().delay(800);	*/		
			}
			
			function animate()
			{
				let path_length=this.getTotalLength();
				let path_iter=d3.interpolateString("0,"+path_length,path_length+","+path_length);
				return function(it){ 
					return path_iter(it);
				};
			  }
			  
			function transitLine(svg_path)
			{
				svg_path.transition(t)
					.delay(function(d,i){ return 100*i; })
					.attrTween("stroke-dasharray",animate)
					.on("end",()=>{ 
					  lineLegends();
					});
					
			  }
			 
			svg.selectAll(".line")
				.data(data)
				.join(
					(enter) =>
							enter.append("path")
								 .attr("d", function(d){
											
											console.log();
											return d3.line().curve(d3.curveLinear)
											.x(function(d) {console.log('1',x_scl(d.Year),'2',y_scl(d[ind_option])); if(d.Year>=start && d.Year<=end){return x_scl(d.Year); }else{return x_scl(0);
											}})
											.y(function(d) { if(d.Year>=start && d.Year<=end){return y_scl(d[ind_option]); }else{//return y_scl(0);
											}})
											(d[1])
										})
								.transition(t)
								.attr("fill", "none")
								.attr("stroke", function(d){return d[1][0]["Color"]; })
								.attr("stroke-width", '1.5')
								.attr('opacity', '0.5')
								.selection(),
		
					  (update)=>
					  			update
									.transition(t)
									.attr("d", function(d){
										return d3.line()
										.x(function(d) { if(d.Year>=start && d.Year<=end){return x_scl(d.Year); }else{return 0;}})
										.y(function(d) { if(d.Year>=start && d.Year<=end){return y_scl(d[ind_option]); }else{return 0;}})
										(d[1])
									})
									.selection(),

					  (exit)=> exit.transition(t).attr("d","0").remove()
						                
				)
				
				.attr("id","line")
				.on("mouseover", function(d,i) {
					//console.log(d,i[1]);
					d3.select(this)
					  .style("stroke-width", 5).select("#lab").style("stroke-width", 1.5).select("#cir").style("stroke-width", 2);
					 })	
					  .on("mouseout", function(d,i) {
						d3.select(this)
						  .style("stroke-width", 1.5).select("#lab").style("stroke-width", 0.7).select("#cir").style("stroke-width", 1);
						})
				.attr("fill", "none")
				.attr("stroke", function(d){return d[1][0]["Color"]; })
				.call(transitLine);				  
		}
		update(GD_filter,data2,ind_select);

		d3.select("#play-button").on("click", function() {
			svg.selectAll("path").remove();
			//svg.selectAll("#yScale").remove();
			//svg.selectAll("#xScale").remove();
			svg.selectAll("#lab").remove();
			svg.selectAll("#cir").remove();
			update(GD_filter,data2,ind_select);
		});
	
		d3.select("#range1").on("input", function () {
				svg.selectAll('#line')
					.transition()
					.duration(1000)
					.ease(d3.easeLinear)
					.style("opacity", d3.select("#range1").property("value") / 100);

					svg.selectAll("#lab").transition()
					.duration(1000)
					.ease(d3.easeLinear)
					.style("opacity", d3.select("#range1").property("value") / 100);

					svg.selectAll("#cir").transition()
					.duration(1000)
					.ease(d3.easeLinear)
					.style("opacity", d3.select("#range1").property("value") / 100);
			});


		d3.select("#flexSwitchCheckDefault").on('change', function () {
			if (this.checked) {
				console.log("Checkbox is checked..");
				svg.selectAll("#lab").remove();
				svg.selectAll("myLabels")
					.data(data2)
					.enter()
					.append('g')
					.append('image')
					.datum(function(d) { return {Country:d[1][0]["Country"], FlagSVG:d[1][0]["FlagSVG"], Year: d[1][d[1].length-1]["Year"], Color:d[1][d[1].length-1]["Color"], Value: d[1][d[1].length-1][ind_select]}; })
					//.transition().ease(d3.easeLinear).delay(750)
					.attr("transform", function(d) { //console.log('999',d);  
						return "translate(" + x_scl(d.Year) + "," + y_scl(d.Value) + ")"; })
    				.attr('xlink:href', function(d) { return d.FlagSVG;})
    				.attr("id","img")
					.attr('x',5)
					.attr('y',-5)
					.attr('width', 30)
    				.attr('height', 30)
					.attr("opacity", 0)
  					.transition()
					.duration(500)
					.attr("opacity", 1);
			}
			else {
				console.log("Checkbox is not checked..");
				svg.selectAll("#img").remove();
				svg.selectAll("myLabels")
						.data(data2)
						.enter()
						.append('g')
						.append("text")
						.datum(function(d) { return {Country:d[1][0]["Country"], Year: d[1][d[1].length-1]["Year"], Color:d[1][d[1].length-1]["Color"], Value: d[1][d[1].length-1][ind_select]}; })
							//.transition().ease(d3.easeLinear).delay(750)
							.attr("transform", function(d) { //console.log('999',d);  
								return "translate(" + x_scl(d.Year) + "," + y_scl(d.Value) + ")"; })
							.attr("id","lab")
							.attr('x',5)
							.text(function(d) { return d.Country; })
							.style("fill", function(d){ return d.Color; })
							.style("font-size", '15')
							.attr("opacity", 0)
  							.transition()
							.duration(500)
					    	.attr("opacity", 1);
							//.transition().delay(800);
			}
		});

		

	}
}
