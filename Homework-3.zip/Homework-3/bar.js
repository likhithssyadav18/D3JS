let svg_bar=document.querySelector('svg')
const width=parseInt(getComputedStyle(svg_bar).width,10);
const height=parseInt(getComputedStyle(svg_bar).height,10);

const margin={top: 30,right: 20,bottom: 50,left: 80};
const innerWidth=width -margin.left-margin.right;
const innerHeight=height-margin["top"]-margin.bottom;


let svg=d3.select('#bar_svg').append('g')
		.attr("id","bar_g")
		.attr('transform', `translate(${margin.left}, ${margin.top})`);	

			
let tip = d3.select("body")
			.append("div")
			.style("position", "absolute")
			.style("width","auto")
			.style("height","auto")
			.style("text-align","center")
			.style("z-index", "10")
			.style("visibility", "hidden")
			.style("padding", "15px")
			.style("background", "white")
			.style("border", "2px")
			.style("margin", "5px")
			.style("border-radius", "8px")
			.style("color", "black")
			.style("font-family","sans-serif")
			.style("font-size","15px")
			.style("line-height","20px")
			.style("pointer-events","none")

function mouseOver(d,i)
{
	d3.select(this).attr('opacity', '0.8').style("stroke","black").style("stroke-width",4).transition();
							
	document.getElementById('character-name').innerHTML=i.key;
	tip.html(`Character: ${i.key} <br> Frequency: ${i.value}`)
		.style("visibility", "visible")
		.style("left",(event.pageX)+"px")
		.style("top", (event.pageY)+"px");						
}

function mouseOut(d,i)
{
	d3.select(this).attr('opacity', '1').style('stroke-width',1);
	tip.style("visibility", "hidden");					
}

function mouseMove(d,i)
{
	tip.style("top", (event.pageY)+"px").style("left",(event.pageX)+"px");
}


function barChart(input,type,lab,cls)
{
	//console.log(vow);
	let bkey=[],bval=[];
	for (const [a,b] of Object.entries(input)) {
		bkey.push(b["key"]);
		bval.push(b["value"]);
	}
	
	//console.log(vow_key,vow_val);
	
	let x=d3.scaleBand()
		.domain(bkey)
		.range([0,innerWidth])
		.padding(0.2);
  
	let y=d3.scaleLinear()
			.domain(d3.extent(bval))
			.nice()
			.range([innerHeight,0]);
	
	let y_axis=d3.axisLeft(y);
	
	svg.append('g')
		.call(y_axis)
		.style('font-size','15px');

	let x_axis=d3.axisBottom(x);
	svg.append('g')
		.call(x_axis)
		.attr('transform',`translate(0,${innerHeight})`)
		.selectAll('text')                   
		.style('text-anchor', 'middle')     
		.attr('dx','0px')             
		.attr('dy','10px')
		.style('font-size','15px')								
		.attr('transform','rotate(0)');
		
	svg.append('text')
		.attr('transform','rotate(-90)')
		.attr('y',-40)
		.attr('x',-innerHeight/2)
		.attr('text-anchor','middle')
		.text('Frequency')
		
	svg.append('text')
		.attr('text-anchor','middle')
		.attr('x',innerWidth/2)
		.attr('y',innerHeight+40)
		.text(lab)
			
	svg.selectAll(cls)
		.data(input)
		.enter()
		.append('rect')
		.attr("class",type)
		.attr("x",(c)=>x(c.key))
		.attr('y',(d)=>y(d.value))
		.attr('width', x.bandwidth())
		.on("mouseover", mouseOver)
		.on("mouseout",mouseOut)
		.on("mousemove",mouseMove)
		.transition().ease(d3.easeLinear).duration(250).delay(function(d,i){return i * 10})
		.attr('height', d=>innerHeight-y(d.value));
}
