infoCharacters <- read.csv("C:/Users/sseera/Desktop/D3/Homework-5/data/abc.csv", na.strings = c("-", "-99"))
infoPowers <- read.csv("C:/Users/sseera/Desktop/D3/Homework-5/data/abili.csv")
infoStats <- read.csv("C:/Users/sseera/Desktop/D3/Homework-5/data/marvel_vs_dc.csv", na.strings = "")


colnames(infoCharacters)[colnames(infoCharacters) == "name"] <- "Name"
marvelDcInfo <- infoCharacters[(infoCharacters$Publisher == "Marvel Comics" | infoCharacters$Publisher == "DC Comics"), ]


marvelDcInfo <- marvelDcInfo[!duplicated(marvelDcInfo$Name), ]
marvelDcInfo <- marvelDcInfo %>%
  select(Name, Gender, Publisher)

marvelDcStatsInfo <- join(marvelDcInfo, infoStats, by = "Name", type = "inner")
colnames(infoPowers)[colnames(infoPowers) == "hero_names"] <- "Name"
fullMarvelDc <- join(marvelDcStatsInfo, infoPowers, by = "Name", type = "inner")

marvelDc <- melt(fullMarvelDc, id = c("Name", "Gender", "Publisher", "Alignment", "Intelligence", 
                                      "Strength", "Speed", "Durability", "Power", "Combat", "Total"))
colnames(marvelDc)[colnames(marvelDc) == "variable"] <- "SuperPower"
marvelDc <- marvelDc %>%
  filter(value == "True") %>%
  select(-value)

write.csv(marvelDc, "Marvel_vs_DC.csv", row.names=TRUE)