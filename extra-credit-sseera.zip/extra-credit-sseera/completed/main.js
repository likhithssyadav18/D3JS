let data,mega_primal_filter,legendary_filter,mythical_filter,ordinary_filter;
let mega_primal_filter_type,legendary_filter_type,mythical_filter_type,ordinary_filter_type;
let category_set;

document.addEventListener('DOMContentLoaded', function () {
   
    Promise.all([d3.csv('Pokemon_Database.csv',function(d) {
											return {
													Generation: +d.Generation,
													Type_A: d['Type1'],
													Type_B: d['Type2'],
													Region_Forme: d.Region_Forme,
													Mega_Evolution_Flag: d.Mega_Evolution_Flag,
                                                    Category: d.Category,
													Horse_Power: +d["HP"],
													Attack: +d.Attack,
													Defense: +d.Defense,
													SP_Attack: +d.SP_Attack,
													SP_Defense: +d.SP_Defense,
                                                    Speed: +d.Speed,
                                                    Total: +d.Total
												};
											})
				])	
        .then(function(values) {
            console.log('Loaded Pokedex...');
            data=values[0];
            let category=[];
			mega_primal_filter=data.filter(obj => {
				if (obj.Mega_Evolution_Flag === "Mega" || obj.Mega_Evolution_Flag === "Primal"){
					category.push("Mega");
					return true;
				}
			});

			legendary_filter=data.filter(obj => {
				if (obj.Category === "Legendary"){
					category.push(obj.Category);
					return true;
				}
			});

			mythical_filter=data.filter(obj => {
				if (obj.Category === "Mythical"){
						category.push(obj.Category);
						return true;
				}
			});

			ordinary_filter=data.filter(obj => {
				if (obj.Category === "Ordinary"){
					category.push(obj.Category);
					return true;
				}
			});

			let set = new Set(category);
			category_set = [...set];
			getTypeFilter(mega_primal_filter,legendary_filter,mythical_filter,ordinary_filter,category_set);
		});
});

function getTypeFilter(mega_primal_filter,legendary_filter,mythical_filter,ordinary_filter,category_set)
{
	//console.log(mega_primal_filter)
	let type_A=d3.select("#type_A").property('value');
	let type_B=d3.select("#type_B").property('value');
	if(type_B==="NA")
	{
		type_B="";
	}
	mega_primal_filter_type=mega_primal_filter.filter(obj => {
		if (type_A!==type_B && obj.Type_A === type_A && obj.Type_B === type_B){
			return true;
		}
	});
	//console.log(mega_primal_filter_type)
	legendary_filter_type=legendary_filter.filter(obj => {
		if (type_A!==type_B && obj.Type_A === type_A && obj.Type_B === type_B){
			return true;
		}
	});

	mythical_filter_type=mythical_filter.filter(obj => {
		if (type_A!==type_B && obj.Type_A === type_A && obj.Type_B === type_B){
			return true;
		}
	});

	ordinary_filter_type=ordinary_filter.filter(obj => {
		if (type_A!==type_B && obj.Type_A === type_A && obj.Type_B === type_B){
			return true;
		}
	});

	if(ordinary_filter_type.length === 0)
	{
		document.getElementById("ordinary_demo").innerHTML="<h4>Pokemons not available for these types.</h4>";
	}
	else{
		document.getElementById("ordinary_demo").innerHTML="";
	}

	if(mega_primal_filter_type.length === 0)
	{
		document.getElementById("mega_demo").innerHTML="<h4>Pokemons not available for these types.</h4>";
	}
	else{
		document.getElementById("mega_demo").innerHTML="";
	}

	if(legendary_filter_type.length === 0)
	{
		document.getElementById("legendary_demo").innerHTML="<h4>Pokemons not available for these types.</h4>";
	}
	else{
		document.getElementById("legendary_demo").innerHTML="";
	}

	if(mythical_filter_type.length === 0)
	{
		document.getElementById("mythical_demo").innerHTML="<h4>Pokemons not available for these types.</h4>";
	}
	else{
		document.getElementById("mythical_demo").innerHTML="";
	}
	if(type_A==="NA" && type_B==="")
	{
		document.getElementById("mythical_demo").innerHTML="";
		document.getElementById("legendary_demo").innerHTML="";
		document.getElementById("mega_demo").innerHTML="";
		document.getElementById("ordinary_demo").innerHTML="";
	}
	drawSpiderChart(mega_primal_filter_type,legendary_filter_type,mythical_filter_type,ordinary_filter_type,category_set);
}

function drawSpiderChart(mega_primal_filter,legendary_filter,mythical_filter,ordinary_filter,category_set)
{
	//console.log(mega_primal_filter)
	if (mega_primal_filter !== undefined && legendary_filter !== undefined && mythical_filter !== undefined && ordinary_filter !== undefined) {
		data=mega_primal_filter; data=legendary_filter; data=mythical_filter; data=ordinary_filter;
	}

	let svg_radar=document.querySelector('svg');
	const width=parseInt(getComputedStyle(svg_radar).width,10);
	const height=parseInt(getComputedStyle(svg_radar).height,10);
		
	const margin = {top: 90, right: 70, bottom:120, left: 70};
	const innWidth=width-margin.left-margin.right;
	const innHeight=height-margin.top-margin.bottom;

	let data_mega_primal=[ 
					[
						{axis:"HP",value:d3.median(mega_primal_filter, d => d.Horse_Power)},
						{axis:"Attack",value:d3.median(mega_primal_filter, d => d.Attack)},
						{axis:"Defense",value:d3.median(mega_primal_filter, d => d.Defense)},
						{axis:"Special Attack",value:d3.median(mega_primal_filter, d => d.SP_Attack)},
						{axis:"Special Defense",value:d3.median(mega_primal_filter, d => d.SP_Defense)},
						{axis:"Speed",value:d3.median(mega_primal_filter, d => d.Speed)}
					]
				];	
	
	let data_legendary=[ 
					[
						{axis:"HP",value:d3.median(legendary_filter, d => d.Horse_Power)},
						{axis:"Attack",value:d3.median(legendary_filter, d => d.Attack)},
						{axis:"Defense",value:d3.median(legendary_filter, d => d.Defense)},
						{axis:"Special Attack",value:d3.median(legendary_filter, d => d.SP_Attack)},
						{axis:"Special Defense",value:d3.median(legendary_filter, d => d.SP_Defense)},
						{axis:"Speed",value:d3.median(legendary_filter, d => d.Speed)}
					]
				];	

	let data_mythical=[ 
					[		
						{axis:"HP",value:d3.median(mythical_filter, d => d.Horse_Power)},
						{axis:"Attack",value:d3.median(mythical_filter, d => d.Attack)},
						{axis:"Defense",value:d3.median(mythical_filter, d => d.Defense)},
						{axis:"Special Attack",value:d3.median(mythical_filter, d => d.SP_Attack)},
						{axis:"Special Defense",value:d3.median(mythical_filter, d => d.SP_Defense)},
						{axis:"Speed",value:d3.median(mythical_filter, d => d.Speed)}
					]
				];
	
	let data_ordinary=[ 
					[		
						{axis:"HP",value:d3.median(ordinary_filter, d => d.Horse_Power)},
						{axis:"Attack",value:d3.median(ordinary_filter, d => d.Attack)},
						{axis:"Defense",value:d3.median(ordinary_filter, d => d.Defense)},
						{axis:"Special Attack",value:d3.median(ordinary_filter, d => d.SP_Attack)},
						{axis:"Special Defense",value:d3.median(ordinary_filter, d => d.SP_Defense)},
						{axis:"Speed",value:d3.median(ordinary_filter, d => d.Speed)}
					]
				];
	let color_mega_primal=d3.scaleOrdinal(d3.schemeAccent).domain(category_set[0]).range(["#A52A2A"]); 	
	let color_legendary=d3.scaleOrdinal(d3.schemeAccent).domain(category_set[1]).range(["#72A0C1"]);
	let color_mythical=d3.scaleOrdinal(d3.schemeAccent).domain(category_set[1]).range(["#568203"]);
	let color_ordinary=d3.scaleOrdinal(d3.schemeAccent).domain(category_set[1]).range(["#F0E68C"]);
	 
	let radarChartOptions_megaprimal={
					  w: innWidth,
					  h: innHeight,
					  margin: margin,
					  maxValue: 0.5,
					  levels: 10,
					  roundStrokes: true,
					  color: color_mega_primal
				};

	let radarChartOptions_legendary={
						w: innWidth,
						h: innHeight,
						margin: margin,
						maxValue: 0.5,
						levels: 10,
						roundStrokes: true,
						color: color_legendary
			  	};

	let radarChartOptions_mythical={
						w: innWidth,
						h: innHeight,
						margin: margin,
						maxValue: 0.5,
						levels: 10,
						roundStrokes: true,
						color: color_mythical
				};

	let radarChartOptions_ordinary={
						w: innWidth,
						h: innHeight,
						margin: margin,
						maxValue: 0.5,
						levels: 10,
						roundStrokes: true,
						color: color_ordinary
				};
	if(mega_primal_filter.length===0)
	{
		d3.select("#mega_svg").select("svg").remove();
	}
	else{
		RadarChart("#mega_svg", data_mega_primal, radarChartOptions_megaprimal,category_set[0],mega_primal_filter);
	}
	
	if(legendary_filter.length===0)
	{
		d3.select("#legendary_svg").select("svg").remove();
	}
	else{
		RadarChart("#legendary_svg", data_legendary, radarChartOptions_legendary,category_set[1],legendary_filter);
	}

	if(mythical_filter.length===0)
	{
		d3.select("#mythical_svg").select("svg").remove();
	}
	else{
		RadarChart("#mythical_svg", data_mythical, radarChartOptions_mythical,category_set[2],mythical_filter);
	}

	if(ordinary_filter.length===0)
	{
		d3.select("#ordinary_svg").select("svg").remove();
	}
	else{
		RadarChart("#ordinary_svg", data_ordinary, radarChartOptions_ordinary,category_set[3],ordinary_filter);
	}			
}


function RadarChart(id,data,options,publisher,filler) {
	d3.select(id).select("svg").remove();
	let cfg = {
	 w: 600,				
	 h: 600,
	 margin: {top: 20, right: 20, bottom: 20, left: 20}, 
	 levels: 3,				
	 maxValue: 0, 			
	 labelFactor: 1.25, 	
	 wrapWidth: 60, 		
	 opacityArea: 0.35, 	
	 dotRadius: 4, 			
	 opacityCircles: 0.1, 	
	 strokeWidth: 2, 		
	 roundStrokes: false,
	 color: d3.scaleOrdinal(d3.schemeAccent)	
	};
	
	if('undefined' !== typeof options){
	  for(let i in options){
		if('undefined' !== typeof options[i]){ cfg[i] = options[i]; }
	  }
	}

	let maxValue = Math.max(cfg.maxValue, d3.max(data, function(i){return d3.max(i.map(function(o){return o.value;}))}));
		
	let allAxis = (data[0].map(function(i, j){return i.axis})),	
		total = allAxis.length,					
		radius = Math.min(cfg.w/2, cfg.h/2), 	
		Format = d3.format(''),			 	
		angleSlice = Math.PI * 2 / total;
	
	let rScale = d3.scaleLinear()
		.range([0, radius])
		.domain([0, maxValue]);
	
	let svg = d3.select(id).append("svg")
			.attr("width",  cfg.w + cfg.margin.left + cfg.margin.right)
			.attr("height", cfg.h + cfg.margin.top + cfg.margin.bottom)
			.attr("class", "radar"+id);
		
	let g = svg.append("g")
			.attr("transform", "translate(" + (cfg.w/2 + cfg.margin.left) + "," + (cfg.h/2 + cfg.margin.top) + ")");
	
	let axisGrid = g.append("g").attr("class", "axisWrapper");
	
	axisGrid.selectAll(".levels")
	   .data(d3.range(1,(cfg.levels+1)).reverse())
	   .enter()
		.append("circle")
		.attr("class", "gridCircle")
		.attr("r", function(d, i){return radius/cfg.levels*d;})
		.style("fill", "#CDCDCD")
		.style("stroke", "#CDCDCD")
		.style("fill-opacity", cfg.opacityCircles)
	
	axisGrid.selectAll(".axisLabel")
	   .data(d3.range(1,(cfg.levels+1)).reverse())
	   .enter().append("text")
	   .attr("class", "axisLabel")
	   .attr("x", 4)
	   .attr("y", function(d){return -d*radius/cfg.levels;})
	   .attr("dy", "0.4em")
	   .style("font-size", "12px")
	   .attr("fill", "#737373")
	   .text(function(d,i) { return Format(maxValue * d/cfg.levels); });
	
	let axis = axisGrid.selectAll(".axis")
		.data(allAxis)
		.enter()
		.append("g")
		.attr("class", "axis");

	axis.append("line")
		.attr("x1", 0)
		.attr("y1", 0)
		.attr("x2", function(d, i){ return rScale(maxValue*1.1) * Math.cos(angleSlice*i - Math.PI/2); })
		.attr("y2", function(d, i){ return rScale(maxValue*1.1) * Math.sin(angleSlice*i - Math.PI/2); })
		.attr("class", "line")
		.style("stroke", "white")
		.style("stroke-width", "2px");

	axis.append("text")
		.attr("class", "legend")
		.style("font-size", "15px")
		.attr("text-anchor", "middle")
		.attr("dy", "0.25em")
		.attr("x", function(d, i){ return rScale(maxValue * cfg.labelFactor) * Math.cos(angleSlice*i - Math.PI/2); })
		.attr("y", function(d, i){ return rScale(maxValue * cfg.labelFactor) * Math.sin(angleSlice*i - Math.PI/2); })
		.text(function(d){return d})
		.call(wrap, cfg.wrapWidth);

	let radarLine = d3.lineRadial()
		.radius(function(d) { return rScale(d.value); })
		.angle(function(d,i) {	return i*angleSlice; })
		.curve(d3.curveLinearClosed);
		
	if(cfg.roundStrokes) {
		radarLine.curve(d3.curveLinearClosed);
	}
				
	let blobWrapper = g.selectAll(".radarWrapper")
		.data(data)
		.enter().append("g")
		.attr("class", "radarWrapper");
			
	blobWrapper
		.append("path")
		.attr("class", "radarArea")
		.attr("d", function(d,i) { return radarLine(d); })
		.style("fill", function(d,i) { return cfg.color(i); })
		.style("fill-opacity", cfg.opacityArea)
		.on('mouseover', function (d,i){
			d3.selectAll(".radarArea")
				.transition().duration(200)
				.style("fill-opacity", 0.1); 

			d3.select(this)
				.transition().duration(200)
				.style("fill-opacity", 0.7);

			tip.html(`${publisher}<br> Overall: ${d3.median(filler,d=>d.Total)}`)
				.style("visibility", "visible")
				.style("left",(event.pageX)+"px")
				.style("top", (event.pageY)+"px")
				.transition().duration(200);	
		})
		.on('mouseout', function(){
			d3.selectAll(".radarArea")
				.transition().duration(200)
				.style("fill-opacity", cfg.opacityArea);

			tip.style("visibility", "hidden").transition().duration(200);
		})
		.on("mousemove", function(d,i){
			tip.style("top", (event.pageY)+"px").style("left",(event.pageX)+"px");
		})
		.on("click", function(){
			tip.html("<p>Number of Pokemons based on Regions</p><div id='tipDiv'></div>")
				.style("visibility", "visible")
				.style("left",(event.pageX)+"px")
				.style("top", (event.pageY)+"px")
				.transition().duration(200);

			let margin = {top: 30, right: 30, bottom: 70, left: 70},
			width = 750 - margin.left - margin.right,
			height = 750 - margin.top - margin.bottom;
			
			let tipSVG = d3.select("#tipDiv")
				.append("svg")
				.attr("width", width + margin.left + margin.right)
    			.attr("height", height + margin.top + margin.bottom)
  				.append("g")
    			.attr("transform","translate(" + margin.left + "," + margin.top + ")");

			
			let count=[{"key":"Kanto","value":0},{"key":"Johto","value":0},{"key":"Hoenn","value":0},
					   {"key":"Sinnoh","value":0},{"key":"Unova","value":0},{"key":"Kalos","value":0},
					   {"key":"Alola","value":0},{"key":"Galar","value":0},{"key":"Hisui","value":0}
					];

			filler.filter(obj => {
					if (obj.Generation === 1){
						count[0]["value"]+=1;
					}
					else if (obj.Generation === 2){
						count[1]["value"]+=1;
					}
					else if (obj.Generation	=== 3){
						count[2]["value"]+=1;
					}
					else if (obj.Generation === 4){
						count[3]["value"]+=1;
					}
					else if (obj.Generation	=== 5){
						count[4]["value"]+=1;
					}
					else if (obj.Generation === 6){
						count[5]["value"]+=1;
					}
					else if (obj.Generation	=== 7){
						count[6]["value"]+=1;
					}
					else if (obj.Generation === 8){
						count[7]["value"]+=1;
					}
					else if (obj.Generation === 8 && Region_Forme === "Hisuian"){
						count[8]["value"]+=1;
					}
					else{}
			});

			//console.log(tipSVG)
			let cKey=[],cVal=[];
			for (const [a,b] of Object.entries(count)) {
				cKey.push(b["key"]);
				cVal.push(b["value"]);
			}

			let x=d3.scaleBand()
				.domain(cKey)
				.range([ 0, width ])
				.padding(0.1);
			tipSVG.append('g')
				.call(d3.axisBottom(x))
				.attr('transform',`translate(0,${height})`)
				.selectAll('text')                   
				.style('text-anchor', 'middle')     
				.attr('dx','0px')             
				.attr('dy','10px')
				.style('font-size','18px')								
				.attr('transform','rotate(0)')
				.style("text-anchor", "middle");
			
			tipSVG.append('text')
				.attr('transform','rotate(-90)')
				.attr('y',-50)
				.attr('x',-height/2)
				.attr('text-anchor','middle')
				.style('font-size','14px')
				.text('Number of Pokemons');
			
			let y=d3.scaleLinear()
				.domain(d3.extent(cVal))
				.nice()
				.range([ height, 0]);
			tipSVG.append("g")
				.call(d3.axisLeft(y))
				.style('font-size','18px');
			tipSVG.append('text')
				.attr('text-anchor','left')
				.attr('x',width/2-5)
				.attr('y',height+45)
				.style('font-size','14px')
				.text("Regions");	

			tipSVG.selectAll("mybar")
			.data(count)
			.enter()
			.append("rect")
			  .attr("x", function(d) { return x(d.key); })
			  .attr("y", function(d) { return y(d.value); })
			  .attr("width", x.bandwidth())
			  .transition().ease(d3.easeLinear).duration(250).delay(function(d,i){return i * 10})
			  .attr("height", function(d) { return height - y(d.value); })
			  .attr("fill", cfg.color)
			  .style("stroke","white")
			  .style("stroke-width",2);
		})
		.on("dblclick", function(){
			tip.selectAll('*').remove();
			tip.style("visibility", "hidden");
		});
	blobWrapper.append("path")
		.attr("class", "radarStroke")
		.attr("d", function(d,i) { return radarLine(d); })
		.style("stroke-width", cfg.strokeWidth + "px")
		.style("stroke", function(d,i) { return cfg.color(i); })
		.style("fill", "none")
		.style("filter" , "url(#glow)");		
	
	blobWrapper.selectAll(".radarCircle")
		.data(function(d,i) { return d; })
		.enter().append("circle")
		.attr("class", "radarCircle")
		.attr("r", cfg.dotRadius)
		.attr("cx", function(d,i){ return rScale(d.value) * Math.cos(angleSlice*i - Math.PI/2); })
		.attr("cy", function(d,i){ return rScale(d.value) * Math.sin(angleSlice*i - Math.PI/2); })
		.style("fill", function(d,i,j) { return cfg.color(j); })
		.style("fill-opacity", 0.8);

	let blobCircleWrapper = g.selectAll(".radarCircleWrapper")
		.data(data)
		.enter().append("g")
		.attr("class", "radarCircleWrapper");
		
	blobCircleWrapper.selectAll(".radarInvisibleCircle")
		.data(function(d,i) { return d; })
		.enter().append("circle")
		.attr("class", "radarInvisibleCircle")
		.attr("r", cfg.dotRadius*1.5)
		.attr("cx", function(d,i){ return rScale(d.value) * Math.cos(angleSlice*i - Math.PI/2); })
		.attr("cy", function(d,i){ return rScale(d.value) * Math.sin(angleSlice*i - Math.PI/2); })
		.style("fill", "none")
		.style("pointer-events", "all")
		.on("mouseover", function(d,i) {
			d3.select(this).style("stroke","black").style("stroke-width",5);
			newX =  parseFloat(d3.select(this).attr('cx')) - 10;
			newY =  parseFloat(d3.select(this).attr('cy')) - 10;

			tip.html(`Trait: ${i.axis} <br> Score: ${i.value}`)
				.style("visibility", "visible")
				.style("left",(newX)+"px")
				.style("top", (newY)+"px")
				.transition().duration(200);	
		})
		.on("mouseout", function(){
			d3.select(this).style("stroke","white").style("stroke-width",1);
			tip.style("visibility", "hidden").transition().duration(200);
		})
		.on("mousemove", function(d,i){
			tip.style("top", (event.pageY)+"px").style("left",(event.pageX)+"px");
		});

	let tip = d3.select("body")
		.append("div")
		.style("position", "absolute")
		.style("width","auto")
		.style("height","auto")
		.style("text-align","center")
		.style("z-index", "10")
		.style("visibility", "hidden")
		.style("padding", "15px")
		.style("background", "black")
		.style("border", "2px")
		.style("margin", "5px")
		.style("border-radius", "8px")
		.style("color", "white")
		.style("font-family","sans-serif")
		.style("font-size","15px")
		.style("line-height","20px")
		.style("pointer-events","none");
		
	
	function wrap(text, width) {
	  text.each(function() {
		let text = d3.select(this),
			words = text.text().split(/\s+/).reverse(),
			word,
			line = [],
			lineNumber = 0,
			lineHeight = 1.4, // ems
			y = text.attr("y"),
			x = text.attr("x"),
			dy = parseFloat(text.attr("dy")),
			tspan = text.text(null).append("tspan").attr("x", x).attr("y", y).attr("dy", dy + "em");
			
		while (word = words.pop()) {
		  line.push(word);
		  tspan.text(line.join(" "));
		  if (tspan.node().getComputedTextLength() > width) {
			line.pop();
			tspan.text(line.join(" "));
			line = [word];
			tspan = text.append("tspan").attr("x", x).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
		  }
		}
	  });
	}
	
}