let marvel_dc_csv,marvel_filter,dc_filter;
document.addEventListener('DOMContentLoaded', function () {
   
    Promise.all([d3.csv('data/Marvel_vs_DC.csv',function(d) {
											return {
													Name: d.Name,
													Gender: d.Gender,
													Publisher: d.Publisher,
													Alignment: d.Alignment,
													SuperPower: d.SuperPower,
													Intelligence: +d.Intelligence,
													Strength: +d.Strength,
													Speed: +d.Speed,
													Durability: +d.Durability,
													Power: +d.Power,
                                                    Combat: +d.Combat,
                                                    Total: +d.Total
												};
											})
				])	
        .then(function(values) {
            console.log('Loaded Marvel and DC characters...');
            marvel_dc_csv=values[0];
			let publisher=[];
			marvel_filter=marvel_dc_csv.filter(obj => {
				if (obj.Publisher === "Marvel Comics"){
					publisher.push(obj.Publisher);
					return true;
				}
			});

			dc_filter=marvel_dc_csv.filter(obj => {
			if (obj.Publisher === "DC Comics"){
					publisher.push(obj.Publisher);
					return true;
				}
			});
			let set = new Set(publisher);
			let publisher_set = [...set];
			drawRadarChart(marvel_filter,dc_filter,publisher_set);
		});
});

function drawRadarChart(marvel_filter,dc_filter,publisher_set)
{
	if (marvel_filter !== undefined && dc_filter !== undefined) {
		marvel_dc_csv = marvel_filter; marvel_dc_csv = dc_filter;
	}
	let svg_radar=document.querySelector('svg');
	const width=parseInt(getComputedStyle(svg_radar).width,10);
	const height=parseInt(getComputedStyle(svg_radar).height,10);
		
	const margin = {top: 90, right: 70, bottom:90, left: 70};
	const innWidth=width-margin.left-margin.right;
	const innHeight=height-margin.top-margin.bottom;

	let data_marvel = [ 
					[
						{axis:"Intelligence",value:d3.median(marvel_filter, d => d.Intelligence)},
						{axis:"Strength",value:d3.median(marvel_filter, d => d.Strength)},
						{axis:"Speed",value:d3.median(marvel_filter, d => d.Speed)},
						{axis:"Durability",value:d3.median(marvel_filter, d => d.Durability)},
						{axis:"Power",value:d3.median(marvel_filter, d => d.Power)},
						{axis:"Combat",value:d3.median(marvel_filter, d => d.Combat)},
					]
				];	
	
	let data_dc = [ 
					[
						{axis:"Intelligence",value:d3.median(dc_filter, d => d.Intelligence)},
						{axis:"Strength",value:d3.median(dc_filter, d => d.Strength)},
						{axis:"Speed",value:d3.median(dc_filter, d => d.Speed)},
						{axis:"Durability",value:d3.median(dc_filter, d => d.Durability)},
						{axis:"Power",value:d3.median(dc_filter, d => d.Power)},
						{axis:"Combat",value:d3.median(dc_filter, d => d.Combat)}
					]
				];	
	let color_marvel=d3.scaleOrdinal(d3.schemeAccent).domain(publisher_set[0]).range(["#A52A2A"]); 	
	let color_dc=d3.scaleOrdinal(d3.schemeAccent).domain(publisher_set[1]).range(["#72A0C1"]); 
	let radarChartOptions_marvel={
					  w: innWidth,
					  h: innHeight,
					  margin: margin,
					  maxValue: 0.5,
					  levels: 10,
					  roundStrokes: true,
					  color: color_marvel
					};
	let radarChartOptions_dc={
						w: innWidth,
						h: innHeight,
						margin: margin,
						maxValue: 0.5,
						levels: 10,
						roundStrokes: true,
						color: color_dc
					};
	RadarChart("#marvel_svg", data_marvel, radarChartOptions_marvel,publisher_set[0],marvel_filter);
	RadarChart("#dc_svg", data_dc, radarChartOptions_dc,publisher_set[1],dc_filter);				
}

function RadarChart(id,data,options,publisher,filler) {
	d3.select(id).select("svg").remove();
	let cfg = {
	 w: 600,				
	 h: 600,
	 margin: {top: 20, right: 20, bottom: 20, left: 20}, 
	 levels: 3,				
	 maxValue: 0, 			
	 labelFactor: 1.25, 	
	 wrapWidth: 60, 		
	 opacityArea: 0.35, 	
	 dotRadius: 4, 			
	 opacityCircles: 0.1, 	
	 strokeWidth: 2, 		
	 roundStrokes: false,
	 color: d3.scaleOrdinal(d3.schemeAccent)	
	};
	
	if('undefined' !== typeof options){
	  for(let i in options){
		if('undefined' !== typeof options[i]){ cfg[i] = options[i]; }
	  }
	}

	let maxValue = Math.max(cfg.maxValue, d3.max(data, function(i){return d3.max(i.map(function(o){return o.value;}))}));
		
	let allAxis = (data[0].map(function(i, j){return i.axis})),	
		total = allAxis.length,					
		radius = Math.min(cfg.w/2, cfg.h/2), 	
		Format = d3.format(''),			 	
		angleSlice = Math.PI * 2 / total;
	
	let rScale = d3.scaleLinear()
		.range([0, radius])
		.domain([0, maxValue]);
	
	let svg = d3.select(id).append("svg")
			.attr("width",  cfg.w + cfg.margin.left + cfg.margin.right)
			.attr("height", cfg.h + cfg.margin.top + cfg.margin.bottom)
			.attr("class", "radar"+id);
		
	let g = svg.append("g")
			.attr("transform", "translate(" + (cfg.w/2 + cfg.margin.left) + "," + (cfg.h/2 + cfg.margin.top) + ")");
	
	let filter = g.append('defs').append('filter').attr('id','glow'),
		feGaussianBlur = filter.append('feGaussianBlur').attr('stdDeviation','2.5').attr('result','coloredBlur'),
		feMerge = filter.append('feMerge'),
		feMergeNode_1 = feMerge.append('feMergeNode').attr('in','coloredBlur'),
		feMergeNode_2 = feMerge.append('feMergeNode').attr('in','SourceGraphic');

	let axisGrid = g.append("g").attr("class", "axisWrapper");
	
	axisGrid.selectAll(".levels")
	   .data(d3.range(1,(cfg.levels+1)).reverse())
	   .enter()
		.append("circle")
		.attr("class", "gridCircle")
		.attr("r", function(d, i){return radius/cfg.levels*d;})
		.style("fill", "#CDCDCD")
		.style("stroke", "black")
		.style("fill-opacity", cfg.opacityCircles)
		.style("filter" , "url(#glow)");

	axisGrid.selectAll(".axisLabel")
	   .data(d3.range(1,(cfg.levels+1)).reverse())
	   .enter().append("text")
	   .attr("class", "axisLabel")
	   .attr("x", 4)
	   .attr("y", function(d){return -d*radius/cfg.levels;})
	   .attr("dy", "0.4em")
	   .style("font-size", "12px")
	   .attr("fill", "#737373")
	   .text(function(d,i) { return Format(maxValue * d/cfg.levels); });
	
	let axis = axisGrid.selectAll(".axis")
		.data(allAxis)
		.enter()
		.append("g")
		.attr("class", "axis");

	axis.append("line")
		.attr("x1", 0)
		.attr("y1", 0)
		.attr("x2", function(d, i){ return rScale(maxValue*1.1) * Math.cos(angleSlice*i - Math.PI/2); })
		.attr("y2", function(d, i){ return rScale(maxValue*1.1) * Math.sin(angleSlice*i - Math.PI/2); })
		.attr("class", "line")
		.style("stroke", "black")
		.style("stroke-width", "2px");

	axis.append("text")
		.attr("class", "legend")
		.style("font-size", "12.5px")
		.attr("text-anchor", "middle")
		.attr("dy", "0.25em")
		.attr("x", function(d, i){ return rScale(maxValue * cfg.labelFactor) * Math.cos(angleSlice*i - Math.PI/2); })
		.attr("y", function(d, i){ return rScale(maxValue * cfg.labelFactor) * Math.sin(angleSlice*i - Math.PI/2); })
		.text(function(d){return d})
		.call(textWrap, cfg.wrapWidth);

	let radarLine = d3.lineRadial()
		.radius(function(d) { return rScale(d.value); })
		.angle(function(d,i) {	return i*angleSlice; })
		.curve(d3.curveLinearClosed);
		
	if(cfg.roundStrokes) {
		radarLine.curve(d3.curveCardinalClosed);
	}
				
	let radialBlobWrapper = g.selectAll(".radarWrapper")
		.data(data)
		.enter().append("g")
		.attr("class", "radarWrapper");
			
	radialBlobWrapper
		.append("path")
		.attr("class", "radarArea")
		.attr("d", function(d,i) { return radarLine(d); })
		.style("fill", function(d,i) { return cfg.color(i); })
		.style("fill-opacity", cfg.opacityArea)
		.on('mouseover', function (d,i){
			d3.selectAll(".radarArea")
				.transition().duration(200)
				.style("fill-opacity", 0.1); 

			d3.select(this)
				.transition().duration(200)
				.style("fill-opacity", 0.7);

			tip.html(`${publisher}<br> Overall: ${d3.median(filler,d=>d.Total)}`)
				.style("visibility", "visible")
				.style("left",(event.pageX)+"px")
				.style("top", (event.pageY)+"px")
				.transition().duration(200);	
		})
		.on('mouseout', function(){
			d3.selectAll(".radarArea")
				.transition().duration(200)
				.style("fill-opacity", cfg.opacityArea);

			tip.style("visibility", "hidden").transition().duration(200);
		})
		.on("mousemove", function(d,i){
			tip.style("top", (event.pageY)+"px").style("left",(event.pageX)+"px");
		})
		.on("click", function(){
			tip.html("<p>Alignment-Frequency</p><div id='tipDiv'></div>")
				.style("visibility", "visible")
				.style("left",(event.pageX)+"px")
				.style("top", (event.pageY)+"px")
				.transition().duration(200);

			let margin = {top: 30, right: 30, bottom: 70, left: 60},
			width = 800 - margin.left - margin.right,
			height = 800 - margin.top - margin.bottom;
			
			let tipSVG = d3.select("#tipDiv")
				.append("svg")
				.attr("width", width + margin.left + margin.right)
    			.attr("height", height + margin.top + margin.bottom)
  				.append("g")
    			.attr("transform","translate(" + margin.left + "," + margin.top + ")");

			
			let count=[{"key":"good","value":0},{"key":"bad","value":0},{"key":"neutral","value":0}];

			filler.filter(obj => {
					if (obj.Alignment === "good"){
						count[0]["value"]+=1;
					}
					else if (obj.Alignment === "bad"){
						count[1]["value"]+=1;
					}
					else if (obj.Alignment === "neutral"){
						count[2]["value"]+=1;
					}
					else{}
			});

			console.log(tipSVG)
			let cKey=[],cVal=[];
			for (const [a,b] of Object.entries(count)) {
				cKey.push(b["key"]);
				cVal.push(b["value"]);
			}


			let x=d3.scaleBand()
				.domain(cKey)
				.range([ 0, width ])
				.padding(0.1);
			tipSVG.append('g')
				.call(d3.axisBottom(x))
				.attr('transform',`translate(0,${height})`)
				.selectAll('text')                   
				.style('text-anchor', 'middle')     
				.attr('dx','0px')             
				.attr('dy','10px')
				.style('font-size','18px')								
				.attr('transform','rotate(0)')
				.style("text-anchor", "end");;
			
			tipSVG.append('text')
				.attr('transform','rotate(-90)')
				.attr('y',-40)
				.attr('x',-height/2)
				.attr('text-anchor','middle')
				.style('font-size','14px')
				.text('Frequency');
			
			let y=d3.scaleLinear()
				.domain(d3.extent(cVal))
				.nice()
				.range([ height, 0]);
			tipSVG.append("g")
				.call(d3.axisLeft(y))
				.style('font-size','18px');
			tipSVG.append('text')
				.attr('text-anchor','left')
				.attr('x',width/2-5)
				.attr('y',height+45)
				.style('font-size','14px')
				.text("Alignment");	

			tipSVG.selectAll("mybar")
			.data(count)
			.enter()
			.append("rect")
			  .attr("x", function(d) { return x(d.key); })
			  .attr("y", function(d) { return y(d.value); })
			  .attr("width", x.bandwidth())
			  .transition().ease(d3.easeLinear).duration(250).delay(function(d,i){return i * 10})
			  .attr("height", function(d) { return height - y(d.value); })
			  .attr("text", function(d) { return d.value; })
			  .attr("fill", cfg.color)
		})
		.on("dblclick", function(){
			tip.selectAll('*').remove();
			tip.style("visibility", "hidden");
		});
	radialBlobWrapper.append("path")
		.attr("class", "radarStroke")
		.attr("d", function(d,i) { return radarLine(d); })
		.style("stroke-width", cfg.strokeWidth + "px")
		.style("stroke", function(d,i) { return cfg.color(i); })
		.style("fill", "none")
		.style("filter" , "url(#glow)");		
	
	radialBlobWrapper.selectAll(".radarCircle")
		.data(function(d,i) { return d; })
		.enter().append("circle")
		.attr("class", "radarCircle")
		.attr("r", cfg.dotRadius)
		.attr("cx", function(d,i){ return rScale(d.value) * Math.cos(angleSlice*i - Math.PI/2); })
		.attr("cy", function(d,i){ return rScale(d.value) * Math.sin(angleSlice*i - Math.PI/2); })
		.style("fill", function(d,i,j) { return cfg.color(j); })
		.style("fill-opacity", 0.8);

	let radialBlobCircleWrapper = g.selectAll(".radarCircleWrapper")
		.data(data)
		.enter().append("g")
		.attr("class", "radarCircleWrapper");
		
	radialBlobCircleWrapper.selectAll(".radarInvisibleCircle")
		.data(function(d,i) { return d; })
		.enter().append("circle")
		.attr("class", "radarInvisibleCircle")
		.attr("r", cfg.dotRadius*1.5)
		.attr("cx", function(d,i){ return rScale(d.value) * Math.cos(angleSlice*i - Math.PI/2); })
		.attr("cy", function(d,i){ return rScale(d.value) * Math.sin(angleSlice*i - Math.PI/2); })
		.style("fill", "none")
		.style("pointer-events", "all")
		.on("mouseover", function(d,i) {
			newX =  parseFloat(d3.select(this).attr('cx')) - 10;
			newY =  parseFloat(d3.select(this).attr('cy')) - 10;

			tip.html(`Trait: ${i.axis} <br> Score: ${i.value}`)
				.style("visibility", "visible")
				.style("left",(newX)+"px")
				.style("top", (newY)+"px")
				.transition().duration(200);	
		})
		.on("mouseout", function(){
			tip.style("visibility", "hidden").transition().duration(200);
		})
		.on("mousemove", function(d,i){
			tip.style("top", (event.pageY)+"px").style("left",(event.pageX)+"px");
		});

	let tip = d3.select("body")
		.append("div")
		.style("position", "absolute")
		.style("width","auto")
		.style("height","auto")
		.style("text-align","center")
		.style("z-index", "10")
		.style("visibility", "hidden")
		.style("padding", "15px")
		.style("background", "black")
		.style("border", "2px")
		.style("margin", "5px")
		.style("border-radius", "8px")
		.style("color", "white")
		.style("font-family","sans-serif")
		.style("font-size","15px")
		.style("line-height","20px")
		.style("pointer-events","none");
		
	
	function textWrap(text, width) {
	  text.each(function() {
		let text = d3.select(this),
			words = text.text().split(/\s+/).reverse(),
			word,
			line = [],
			lineNumber = 0,
			lineHeight = 1.4,
			y = text.attr("y"),
			x = text.attr("x"),
			dy = parseFloat(text.attr("dy")),
			tspan = text.text(null).append("tspan").attr("x", x).attr("y", y).attr("dy", dy + "em");
			
		while (word = words.pop()) {
		  line.push(word);
		  tspan.text(line.join(" "));
		  if (tspan.node().getComputedTextLength() > width) {
			line.pop();
			tspan.text(line.join(" "));
			line = [word];
			tspan = text.append("tspan").attr("x", x).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
		  }
		}
	  });
	}

}