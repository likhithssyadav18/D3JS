
let count=[{"key":"vowels","value":0},{"key":"consonants","value":0},{"key":"punctuations","value":0},{"key":"digits","value":0}];
	
	
let dig=[{"key":"0","value":0},{"key":"1","value":0},{"key":"2","value":0},{"key":"3","value":0},{"key":"4","value":0},{"key":"5","value":0},{"key":"6","value":0},{"key":"7","value":0},{"key":"8","value":0},{"key":"9","value":0}];

let punc=[{"key":".","value":0},{"key":",","value":0},{"key":"?","value":0},{"key":"!","value":0},{"key":";","value":0},{"key":":","value":0},{"key":"-","value":0}];

let cons=[{"key":"b","value":0},{"key":"c","value":0},{"key":"d","value":0},{"key":"f","value":0},{"key":"g","value":0},{"key":"h","value":0},{"key":"j","value":0},{"key":"k","value":0},{"key":"l","value":0},{"key":"m","value":0},
		  {"key":"n","value":0},{"key":"p","value":0},{"key":"q","value":0},{"key":"r","value":0},{"key":"s","value":0},{"key":"t","value":0},{"key":"v","value":0},{"key":"w","value":0},{"key":"x","value":0},{"key":"z","value":0}];

let vow=[{"key":"a","value":0},{"key":"e","value":0},{"key":"i","value":0},{"key":"o","value":0},{"key":"u","value":0},{"key":"y","value":0}];

function submitText()
{
	let wBox=document.getElementById("wordbox");
	let wBox_ns=wBox.value.split(" ").join("");
	let wBox_lc=wBox_ns.toLowerCase();
	
	for(let i=0; i<wBox_lc.length; i++)
	{
		let txt=wBox_lc[i];
		if(txt>="0" && txt<="9")
		{
			count[3]["value"]+=1;
			isDig(txt);
		}
		else if(txt=="."||txt==","||txt=="?"||txt=="!"||txt==";"||txt==":"||txt=="-")
		{
			count[2]["value"]+=1;
			isPunc(txt);
		}
		else if(txt>="a" && txt<="z")
		{
			if(txt=="a"||txt=="e"||txt=="i"||txt=="o"||txt=="u"||txt=="y")
			{
				count[0]["value"]+=1;
				isVow(txt);
			}
			else
			{
				count[1]["value"]+=1;
				isCons(txt);
				
			}
		}
		else
		{
			continue;
		}
	}
	doNut(count,vow,dig,punc,cons);
}
				
function isVow(d)
{
	if(d=="a")	vow[0]["value"]=vow[0]["value"]+1||1;
	else if(d=="e")	vow[1]["value"]=vow[1]["value"]+1||1;
	else if(d=="i")	vow[2]["value"]=vow[2]["value"]+1||1;
	else if(d=="o")	vow[3]["value"]=vow[3]["value"]+1||1;
	else if(d=="u")	vow[4]["value"]=vow[4]["value"]+1||1;
	else	vow[5]["value"]=vow[5]["value"]+1||1;
}

function isPunc(d)
{
	if(d==".")	punc[0]["value"]=punc[0]["value"]+1||1;
	else if(d==",")	punc[1]["value"]=punc[1]["value"]+1||1;
	else if(d=="?")	punc[2]["value"]=punc[2]["value"]+1||1;
	else if(d=="!")	punc[3]["value"]=punc[3]["value"]+1||1;
	else if(d==";")	punc[4]["value"]=punc[4]["value"]+1||1;
	else if(d==":")	punc[5]["value"]=punc[5]["value"]+1||1;
	else	punc[6]["value"]=punc[6]["value"]+1||1;
}	

function isDig(d)
{
	if(d=="1")	dig[1]["value"]=dig[1]["value"]+1||1;
	else if(d=="2")	dig[2]["value"]=dig[2]["value"]+1||1;
	else if(d=="3")	dig[3]["value"]=dig[3]["value"]+1||1;
	else if(d=="4")	dig[4]["value"]=dig[4]["value"]+1||1;
	else if(d=="5")	dig[5]["value"]=dig[5]["value"]+1||1;
	else if(d=="6")	dig[6]["value"]=dig[6]["value"]+1||1;
	else if(d=="7")	dig[7]["value"]=dig[7]["value"]+1||1;
	else if(d=="8")	dig[8]["value"]=dig[8]["value"]+1||1;
	else if(d=="9")	dig[9]["value"]=dig[9]["value"]+1||1;
	else	dig[0]["value"]=dig[0]["value"]+1||1;
}	

function isCons(d)
{	
	if(d=="b")	cons[0]["value"]=cons[0]["value"]+1||1;
	else if(d=="c")	cons[1]["value"]=cons[1]["value"]+1||1;
	else if(d=="d")	cons[2]["value"]=cons[2]["value"]+1||1;
	else if(d=="f")	cons[3]["value"]=cons[3]["value"]+1||1;
	else if(d=="g")	cons[4]["value"]=cons[4]["value"]+1||1;
	else if(d=="h")	cons[5]["value"]=cons[5]["value"]+1||1;
	else if(d=="j")	cons[6]["value"]=cons[6]["value"]+1||1;
	else if(d=="k")	cons[7]["value"]=cons[7]["value"]+1||1;
	else if(d=="l")	cons[8]["value"]=cons[8]["value"]+1||1;
	else if(d=="m")	cons[9]["value"]=cons[9]["value"]+1||1;
	else if(d=="n")	cons[10]["value"]=cons[10]["value"]+1||1;
	else if(d=="p")	cons[11]["value"]=cons[11]["value"]+1||1;
	else if(d=="q")	cons[12]["value"]=cons[12]["value"]+1||1;
	else if(d=="r")	cons[13]["value"]=cons[13]["value"]+1||1;
	else if(d=="s")	cons[14]["value"]=cons[14]["value"]+1||1;
	else if(d=="t")	cons[15]["value"]=cons[15]["value"]+1||1;
	else if(d=="v")	cons[16]["value"]=cons[16]["value"]+1||1;
	else if(d=="w")	cons[17]["value"]=cons[17]["value"]+1||1;
	else if(d=="x")	cons[18]["value"]=cons[18]["value"]+1||1;
	else	cons[19]["value"]=cons[19]["value"]+1||1;
}