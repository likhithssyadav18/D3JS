document.addEventListener('DOMContentLoaded', function () {
   
    Promise.all([d3.csv('Pokemon_Database.csv')])	
        .then(function(values) {
            console.log('Loaded Pokedex...');
            data=values[0];
			drawSpiderChart(data);
		});
});

function drawSpiderChart(input)
{
    //Code starts here 
}